//
//  ScoreModel.h
//  EatingSnake
//
//  Created by 李志彬 on 2017/6/13.
//  Copyright © 2017年 李志彬. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ScoreModel : NSObject
@property (nonatomic, copy) NSString *player;
@property (nonatomic, assign) int score;
@end
