//
//  LoginVC.h
//  EatingSnake
//
//  Created by 李志彬 on 2017/6/12.
//  Copyright © 2017年 李志彬. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginVC : UIViewController

@end
